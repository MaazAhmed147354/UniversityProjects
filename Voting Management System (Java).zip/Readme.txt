This project is created using Java
Run it using NetBeans IDE
The database for this project is managed using MS Access