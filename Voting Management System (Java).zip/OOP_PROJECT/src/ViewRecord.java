import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class ViewRecord {
    
    ConnectionToDB data = new ConnectionToDB();
    
    //table candidate
    public void view(JTable table){
        
        try{
            Connection con = data.EstablishConnection();
            Statement st = con.createStatement();
            
            String str = "Select * from CandidateData";
            ResultSet rs = st.executeQuery(str);
            
            table.setModel(DbUtils.resultSetToTableModel(rs));
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    //table citizen
    public void citizenTable(JTable table1){
        try{
            Connection con = data.EstablishConnection();
            Statement st = con.createStatement();
            
            String str = "Select * from CitizenData";
            ResultSet rs = st.executeQuery(str);
            
            table1.setModel(DbUtils.resultSetToTableModel(rs));
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}