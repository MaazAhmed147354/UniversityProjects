import java.sql.*;
import javax.swing.JOptionPane;

public class Candidate{
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    ResultSet res=null;
    
    String name,party,Uname,Upass,Cnic,Age;
    int noOfVotes;
    
    //Logging in user
    public boolean LoginUser(String chkuser,String chkpass){
        //select * from Table_Name where Column1='"+value+"'and Column2='"+value+"'....Col_n='"+value+"';
        String loginString="select * from CandidateData where UName='"+chkuser+"'and UPass='"+chkpass+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(loginString);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        return b;
    }
    
    //Checking candidate eligiblity for registration
    public boolean CheckEligibility(int age,int cnic){
        boolean b;
        if(age>=25){
            String chkElig="select * from CandidateData where CNIC='"+cnic+"'";
            try{
                pstmt=con_obj.prepareStatement(chkElig);
                res=pstmt.executeQuery();
                if(res.next()){
                    b=false;
                }
                else{
                    b=true;
                }
            }
            catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex);
                b=false;
            }
        }
        else{
            b=false;
        }
        return b;
    }
    
    //New candidate registration
    public boolean createCandidate(String name,String pname,int cnic,int age,String uname,String upass){
        boolean b=false;
        //insert into Table_Name(Column1,Column2,...,Col_n)values('"+var1+"','"+var2+"',...,'"+var_n+"');
        String sql="insert into CandidateData(Can_Name,PartyName,CNIC,Age,UName,UPass)values('"+name+"','"+pname+"','"+cnic+"','"+age+"','"+uname+"','"+upass+"')";
        try{
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(sql);
            if(res>0){
//                JOptionPane.showMessageDialog(null, "Inserted");
                b=true;
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    //Check if registration is open or closed
    public boolean CheckRegOpen(){
        boolean reg = true;
        String chkRegOpen="select * from AdminData where ID='"+1+"'";
        try{
            pstmt=con_obj.prepareStatement(chkRegOpen);
            res=pstmt.executeQuery();
            if(res.next()){
                reg=res.getBoolean("Reg_Open");
            }
            else{
                reg=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return reg;
    }
    
    //create from admin dashboard
    public boolean createCandidate2(String name,String pname,int cnic,int age){
        boolean b=false;
        //insert into Table_Name(Column1,Column2,...,Col_n)values('"+var1+"','"+var2+"',...,'"+var_n+"');
        String sql="insert into CandidateData(Can_Name,PartyName,CNIC,Age)values('"+name+"','"+pname+"','"+cnic+"','"+age+"')";
        try{
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(sql);
            if(res>0){
//                JOptionPane.showMessageDialog(null, "Inserted");
                b=true;
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    //delete from admin database
    public boolean deleteRecord(int id){
        boolean b=false;
        //delete from Table_Name where ID='"+id+"';
        String sql="delete from CandidateData where ID='"+id+"'";
        try{
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(sql);
            if(res>0){
                JOptionPane.showMessageDialog(null, "Deleted");
                b=true;
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    //delete from candidate databse
    public boolean deleteRecord2(String Cnic){
        boolean b=false;
        //delete from Table_Name where ID='"+id+"';/
        String sql="delete from CandidateData where CNIC='"+Cnic+"'";
        try{
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(sql);
            if(res>0){
                JOptionPane.showMessageDialog(null, "Deleted");
                b=true;
            }
            else{
                JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    //change password of candidate
    public boolean changePassword(String user,String oldPass, String newPass){
        //select * from Table_Name where Column1='"+value+"'and Column2='"+value+"'....Col_n='"+value+"';
        String change="select * from CandidateData where UName='"+user+"'and UPass='"+oldPass+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(change);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        change="UPDATE CandidateData SET UPass='"+newPass+"' WHERE UName='"+user+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(change);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                b=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(SQLException ex){
           JOptionPane.showMessageDialog(null, "Error");
           b=false;
        }
        return b;
    }
    
    //search data from database
    public boolean findCandidate(int id){
        boolean b = false;
        
        String sql = "select* from CandidateData where ID = '"+id+"'";
        try{
            pstmt = con_obj.prepareStatement(sql);
            res = pstmt.executeQuery();
            while(res.next()){
                name = res.getString("Can_Name");
                party = res.getString("PartyName");
                Cnic = res.getString("CNIC");
                Age = res.getString("Age");
                Uname = res.getString("UName");
                Upass = res.getString("UPass");

                b= true;
            }                     
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "NO Record Found");
        }
        return b;
    }
    
    //account check for candidate dashboard
    public boolean accountCheck(int cnic){
        
        String cnicCheck="select* from CandidateData where CNIC='"+cnic+"'";
        boolean b;
        try{
            pstmt=con_obj.prepareStatement(cnicCheck);
            res=pstmt.executeQuery();
            if(res.next()){
                b=true;
            }
            else{
                b=false;
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "NO CNIC Record");
            b=false;
        }
        return b;        
    }
    
    public boolean voteAddUp(String candName){
        String votePlus="select * from CandidateData where Can_Name='"+candName+"'";
        try{
            pstmt=con_obj.prepareStatement(votePlus);
            res=pstmt.executeQuery();
            if(res.next()){
                noOfVotes = res.getInt("VoteCount");
            }
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        boolean pass;
        noOfVotes=noOfVotes+1;
        String updateVoteCount="UPDATE CandidateData SET VoteCount='"+noOfVotes+"' WHERE Can_Name='"+candName+"'";
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(updateVoteCount);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                pass=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                pass=false;
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, ex);
           pass=false;
        }
        return pass;
    }
    
    public boolean updateUser(String name,String pname,int Cnic,int Age,int id){
        String updateString="UPDATE CandidateData SET Can_Name='"+name+"',PartyName='"+pname+"',CNIC='"+Cnic+"',Age='"+Age+"' WHERE ID='"+id+"'";
        boolean b=false;
        try{   
            stmt=con_obj.createStatement();
            int res=stmt.executeUpdate(updateString);
            if(res>0){
                //JOptionPane.showMessageDialog(null, "Updated");
                b=true;
            }
            else{
                //JOptionPane.showMessageDialog(null, "Error");
                b=false;
            }
        }
        catch(Exception ex){
           JOptionPane.showMessageDialog(null, "Error");
        }
        return b;
    }
}
