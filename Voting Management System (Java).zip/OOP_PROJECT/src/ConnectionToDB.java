import java.sql.*;
import javax.swing.JOptionPane;

public class ConnectionToDB {
    Connection con=null;
    
    public Connection EstablishConnection(){
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Hamza\\OneDrive - Higher Education Commission\\Desktop\\voting system\\VotingManagementSystem.accdb");
            //JOptionPane.showMessageDialog(null, "Connected");
        }
        catch(ClassNotFoundException | SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return con;
    }      
}
