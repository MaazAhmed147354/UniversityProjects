import re

class Node:
    def __init__(self, value, children=None):
        self.value = value
        self.children = children or []

    def __repr__(self, level=0):
        ret = "\t" * level + repr(self.value) + "\n"
        for child in self.children:
            ret += child.__repr__(level + 1)
        return ret


def parse(tokens):
    root = Node("Program", [])
    current_node = root

    for token_type, token_value in tokens:
        if token_type in ["FixIter", "BeforeIter", "AfterIter", "This", "That", "ThisNorThat"]:
            current_node.children.append(Node(token_type, []))
            current_node = current_node.children[-1]
        elif token_type in ["IDENTIFIER", "KEYWORD", "OPERATOR", "SYMBOL", "DATATYPE"]:
            current_node.children.append(Node((token_type, token_value)))


    return root

def tokenize(input_code):
    keywords = {'This', 
                'That', 
                'ThisNorThat',
                'FixIter', 
                'BeforeIter', 
                'AfterIter', 
                'Choice', 
                'event', 
                'break', 
                'ret',
                'keyIn', 
                'keyOut', 
                'Frame', 
                'Static'}

    datatypes = {'NUM', 
                 'ftNUM', 
                 'SPAR', 
                 'CPAR', 
                 'ONOF', 
                 'Blank'}

    operators = {'+',
                 '-',
                 '*', 
                 '/', 
                 '%', 
                 '=', 
                 '+=', 
                 '-=', 
                 '/=', 
                 '%=', 
                 '/\\', 
                 '\\/', 
                 '<>', 
                 '==', 
                 '<', 
                 '>', 
                 '<=', 
                 '>='}

    symbols = {'{', 
               '}', 
               '(', 
               ')', 
               ';', 
               ','}

    code_lines = input_code.split('\n')  # Split code into lines
    tokens = []

    for line in code_lines:
        words = re.findall(r'[^ \t\n\r\f\v;]+|;|//.*$', line)  # Tokenize each line
        for word in words:
            if word in keywords:
                tokens.append(('KEYWORD', word))
            elif word in datatypes:
                tokens.append(('DATATYPE', word))
            elif word in operators:
                tokens.append(('OPERATOR', word))
            elif word in symbols:
                tokens.append(('SYMBOL', word))
            elif re.match(r'^\d+$', word):
                tokens.append(('NUM', int(word)))
            elif re.match(r'^\d+\.\d+$', word):
                tokens.append(('ftNUM', float(word)))
            elif re.match(r'^"[^"]*"$', word):
                tokens.append(('SPAR', word[1:-1]))
            elif re.match(r"^'.{1}'$", word):
                tokens.append(('CPAR', word[1]))
            elif word == 'ONOF':
                tokens.append(('ONOF', None))
            else:
                tokens.append(('IDENTIFIER', word))

    return tokens

def generate_intermediate_code(tokens):
    intermediate_code = []

    for idx, (token_type, token_value) in enumerate(tokens):
        if token_type == 'KEYWORD' and token_value == 'keyOut':
            next_value = tokens[idx + 2][1]
            intermediate_code.append(f'PRINT {next_value}')
        elif token_type in ['NUM', 'ftNUM', 'SPAR', 'CPAR']:
            next_value = tokens[idx + 2][1]
            intermediate_code.append(f'{token_value} = {next_value}')
        elif token_type == 'ONOF':
            next_value = tokens[idx + 2][1]
            intermediate_code.append(f'BOOL_VAR = {next_value}')
        elif token_type == 'KEYWORD' and token_value == 'This':
            condition = tokens[idx + 1][1]
            intermediate_code.append(f'IF {condition} THEN')
        elif token_type == 'KEYWORD' and token_value == 'FixIter':
            start_value = tokens[idx + 1][1]
            end_value = tokens[idx + 3][1]
            intermediate_code.append(f'FOR {start_value} TO {end_value}')
        elif token_type == 'KEYWORD' and token_value == 'Choice':
            intermediate_code.append('SWITCH')
            for case in tokens[idx + 1:]:
                if case[0] == 'event':
                    intermediate_code.append(f'CASE {case[1]}:')
                elif case[0] == 'ThisNorThat':
                    intermediate_code.append('DEFAULT:')
                    break
            intermediate_code.append('ENDSWITCH')
        elif token_type == 'SYMBOL' and token_value == '{':
            intermediate_code.append('BEGIN')
        elif token_type == 'SYMBOL' and token_value == '}':
            intermediate_code.append('END')

    return intermediate_code

# Read example code from a file
with open("input.txt", "r") as file:
    example_code = file.read()

tokens = tokenize(example_code)
print("\n\tX---------- TOKENS FOR PREPOSITIONAL LANGUAGE----------X")
for token in tokens:
    print(token)

# Pass tokens to the parse function
parsed_tree = parse(tokens)
print("\n\tX---------- PARSED TREE -----------X")
print(parsed_tree)

# Generate intermediate code based on the parsed tree
intermediate_code = generate_intermediate_code(tokens)
print("\n\tX----------- INTERMEDIATE CODE GENERATION ------------X")
for code_line in intermediate_code:
    print(code_line)