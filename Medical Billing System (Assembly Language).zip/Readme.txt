This project is created using Assembly Language
Can be run on EMU8086 IDE