#include<iostream>
#include<conio.h>
#include<string>
#include<fstream>
using namespace std;
class linked_list{
	private:
		struct node{
			int id, salary;
			string name, dept;
			node *next_add;
		};
		node *head = NULL;
	public:
		void menu();
		void load_data();
		void auto_record();
		void insert_record();
		void search_record();
		void show_record();
		void edit_record();
		void del_record();
};
void linked_list::menu(){
	p:
	system("cls");
	int choice;
	cout <<"\n\t********************************************************************\n\n";
	cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
	cout <<"\n\n\t********************************************************************\n\n";
	cout << "\t0-> Auto Record\n";
	cout << "\t1-> Insert New Record\n";
	cout << "\t2-> Search Record\n";
	cout << "\t3-> Edit Record\n";
	cout << "\t4-> Delete Record\n";
	cout << "\t5-> Show Record\n";
	cout << "\t6-> Exit\n";
	cout << "\n\t--> Enter Your Choice = ";
	cin >> choice;
	cout <<"\n\t**************************************************\n\n";
	switch (choice){
		case 0:
			auto_record();
			break;
		case 1:
			insert_record();
			break;
		case 2:
			head = NULL;
			load_data();
			search_record();
			break;
		case 3:
			head = NULL;
			load_data();
			edit_record();
			break;
		case 4:
			head = NULL;
			load_data();
			del_record();
			break;
		case 5:
			head = NULL;
			load_data();
			show_record();
			break;
		case 6:
			exit(0);
		default:
			cout << "\tInvalid Choice !!! Choose B/W 1 to 6 = ";
	}
	_getch();
	goto p;
}
void linked_list::load_data(){
	fstream file;
	int e_id, e_salary;
	string e_name, e_dept;
	file.open("list.txt", ios::in);
	if (file){
		file >> e_id >> e_name >> e_dept >> e_salary;
		while (!file.eof()){
			node *new_node = new node;
			new_node->id = e_id;
			new_node->name = e_name;
			new_node->dept = e_dept;
			new_node->salary = e_salary;
			if (head == NULL){
				head = new_node;
				new_node->next_add = NULL;
			}
			else{
				node *ptr = head;
				node *ptr2 = NULL;
				while (ptr->next_add != NULL){
					if (e_id > ptr->id){
						ptr2 = ptr;
						ptr = ptr->next_add;
					}
					else if(e_id < ptr->id){
						break;
					}
				}
				if (ptr2 == NULL){
					if (e_id > ptr->id){
						new_node->next_add = head->next_add;
						head->next_add = new_node;
					}
					else if (e_id < ptr->id){
						new_node->next_add = head;
						head = new_node;
					}
				}
				else{
					ptr2->next_add = new_node;
					new_node->next_add = ptr;
				}
			}
			file >> e_id >> e_name >> e_dept >> e_salary;
		}
		file.close();
	}
}
void linked_list::auto_record(){
	system("cls");
	fstream file;
	fstream rec;
	int count = 0;
	int temp_id, temp_sal;
	string temp_name, temp_dept;
	int emp_id, emp_salary;
	string emp_name, emp_dept;
	rec.open("RECORD.txt");
	if(!rec){
		cout<<"FILE NOT OPEN";
	}
	while(!rec.eof()){
		rec >> temp_id;
		rec >> temp_name;
		rec >> temp_dept;
		rec >> temp_sal;
		
		emp_id = temp_id;
		emp_name = temp_name;
		emp_dept = temp_dept;
		emp_salary = temp_sal;	
		
		node *new_node = new node;
		new_node->id = emp_id;
		new_node->name = emp_name;
		new_node->dept = emp_dept;
		new_node->salary = emp_salary;
		new_node->next_add = NULL;
		if (head == NULL){
			head = new_node;
		}
		else{
			node *ptr = head;
			while (ptr->next_add != NULL){
				ptr = ptr->next_add;
			}
			ptr->next_add = new_node;
		}
		file.open("list.txt", ios::app | ios::out);
		file << emp_id << " " << emp_name << " " << emp_dept << " " <<
		emp_salary << "\n";
		file.close();
		count++;	
	}
	rec.close();
	cout << "\n\t" << count << " Records Added Succesfully !!!\n";
}
void linked_list::insert_record(){
	system("cls");
	fstream file;
	int emp_id, emp_salary;
	string emp_name, emp_dept;
	cout <<"\n\t********************************************************************\n\n";
	cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
	cout <<"\n\n\t********************************************************************\n\n";
	q:
	cout << "\n\tEnter Employee ID = ";
	cin >> emp_id;
	cout << "\n\tEnter Employee Name = ";
	cin >> emp_name;
	cout << "\n\tEnter Employee Department = ";
	cin >> emp_dept;
	cout << "\n\tEnter Employee Salary = ";
	cin >> emp_salary;
	node *new_node = new node;
	new_node->id = emp_id;
	new_node->name = emp_name;
	new_node->dept = emp_dept;
	new_node->salary = emp_salary;
	if (head == NULL){
		head = new_node;
		new_node->next_add = NULL;
	}
	else{
		node *ptr = head;
		node *ptr2 = NULL;
		while (ptr->next_add != NULL){
			if (emp_id == ptr->id){
				cout << "\n\n\tEmployee Already Exists with the following ID!!\n";
				cout << "\n\tEnter the Details Again!!\n\n";
				goto q;
			}
			else if (emp_id > ptr->id){
				ptr2 = ptr;
				ptr = ptr->next_add;
			}
			else if (emp_id < ptr->id){
				break;
			}
		}
		if (ptr2 == NULL){
			if (emp_id == ptr->id){
				cout << "\n\n\tEmployee Already Exists with the following ID!!\n";
				cout << "\n\tEnter the Details Again!!\n\n";
				goto q;
			}
			else if (emp_id > ptr->id){
				ptr2 = ptr;
				ptr = ptr->next_add;
				ptr2->next_add = new_node;
				new_node->next_add = ptr;
			}
			else if (emp_id < ptr->id){
				head = new_node;
				new_node->next_add = ptr;
			}
		}
		else{
			ptr2->next_add = new_node;
			new_node->next_add = ptr;
		}
	}
	file.open("list.txt", ios::app | ios::out);
	file << emp_id << " " << emp_name << " " << emp_dept << " " << emp_salary << "\n";
	file.close();
	cout << "\n\tNew Record Inserted Succesfully !!!\n";
}
void linked_list::search_record(){
	system("cls");
	int t_id, found = 0;
	cout <<"\n\t********************************************************************\n\n";
	cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
	cout <<"\n\n\t********************************************************************\n\n";
	if (head == NULL){
		cout << "\tLinked List is Empty !!!";
	}
	else{
		cout << "\tEnter Employee ID = ";
		cin >> t_id;
		node *ptr = head;
		while (ptr != NULL){
			if (ptr->id == t_id){
				system("cls");
				cout <<"\n\t********************************************************************\n\n";
				cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
				cout <<"\n\n\t********************************************************************\n\n";
				cout << "\n\tEmployee ID = " << ptr->id;
				cout << "\n\tEmployee Name = " << ptr->name;
				cout << "\n\tEmployee Department = " << ptr->dept;
				cout << "\n\tEmployee Salary = " << ptr->salary;
				found++;
			}
			ptr = ptr->next_add;
		}
		if (found == 0){
			cout << "\n\tEmployee Not Found !!!";
		}
	}
}
void linked_list::edit_record(){
	system("cls");
	fstream file, file1;
	int t_id, found = 0, emp_id, emp_salary, id, salary;
	string emp_name, emp_dept, name, dept;
	cout <<"\n\t********************************************************************\n\n";
	cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
	cout <<"\n\n\t********************************************************************\n\n";
	if (head == NULL){
		cout << "\tLinked List is Empty !!!";
	}
	else{
		cout << "\tEnter Employee ID = ";
		cin >> t_id;
		file.open("list.txt", ios::in);
		file1.open("list1.txt", ios::app | ios::out);
		file >> emp_id >> emp_name >> emp_dept >> emp_salary;
		while (!file.eof()){
			if (t_id == emp_id){
				system("cls");
				cout <<"\n\t********************************************************************\n\n";
				cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
				cout <<"\n\n\t********************************************************************\n\n";
				cout << "\n\tEnter Employee New ID = ";
				cin >> id;
				cout << "\n\tEnter Employee New Name = ";
				cin >> name;
				cout << "\n\tEnter Employee New Department = ";
				cin >> dept;
				cout << "\n\tEnter Employee New Salary = ";
				cin >> salary;
				file1 << id << " " << name << " " << dept << " " << salary <<
				"\n";
				cout << "\n\tRecord Edited Successfully !!!";
				found++;
			}
			else{
				file1 << emp_id << " " << emp_name << " " << emp_dept << " " << emp_salary << "\n";
			}
			file >> emp_id >> emp_name >> emp_dept >> emp_salary;
		}
		file.close();
		file1.close();
		remove("list.txt");
		rename("list1.txt", "list.txt");
		if (found == 0){
			cout << "\n\tEmployee Not Found !!!";
		}
	}
}
void linked_list::del_record(){
	system("cls");
	fstream file, file1;
	int t_id, found = 0, emp_id, emp_salary;
	string emp_name, emp_dept;
	cout <<"\n\t********************************************************************\n\n";
	cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
	cout <<"\n\n\t********************************************************************\n\n";
	if (head == NULL){
		cout << "\tLinked List is Empty !!!";
	}
	else{
		cout << "\tEnter Employee ID = ";
		cin >> t_id;
		file.open("list.txt", ios::in);
		file1.open("list1.txt", ios::app | ios::out);
		file >> emp_id >> emp_name >> emp_dept >> emp_salary;
		while (!file.eof()){
			if (t_id == emp_id){
				system("cls");
				cout <<"\n\t********************************************************************\n\n";
				cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
				cout <<"\n\n\t********************************************************************\n\n";
				cout << "\n\tDelete Record Successfully !!!";
				found++;
			}
			else{
				file1 << emp_id << " " << emp_name << " " << emp_dept << " " << emp_salary << "\n";
			}
			file >> emp_id >> emp_name >> emp_dept >> emp_salary;
		}
		file.close();
		file1.close();
		remove("list.txt");
		rename("list1.txt", "list.txt");
		if (found == 0){
			cout << "\n\tEmployee Not Found !!!";
		}
	}
}
void linked_list::show_record(){
	system("cls");
	cout <<"\n\t********************************************************************\n\n";
	cout << "\t\t/////////// EMPLOYEE-RECORD-SYSTEM ///////////";
	cout <<"\n\n\t********************************************************************\n\n";
	if (head == NULL){
		cout << "\tLinked List is Empty !!!";
	}
	else{
		cout << "\n\n Employee ID\t\tEmployee Name\t\tEmployee Depart\t\tEmployee Salary";
		node *ptr = head;
		while (ptr != NULL){
			cout << "\n " << ptr->id << "\t\t\t" << ptr->name << "\t\t\t" << ptr->dept << "\t\t\t" << ptr->salary;
			ptr = ptr->next_add;
		}
	}
}
int main(){
	linked_list list;
	list.load_data();
	list.menu();
	system("pause");
}
