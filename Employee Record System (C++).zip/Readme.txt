This project is created using C++
Can be run using Visual Studio or Dev C++