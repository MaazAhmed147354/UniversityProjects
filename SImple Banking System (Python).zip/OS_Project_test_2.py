import tkinter as tk
from tkinter import messagebox


class SimpleBankingSystem:
 def __init__(self):
     self.users = []  # List to store user details (username, password, etc.)


 def run(self):
     # Create the main window
     self.root = tk.Tk()
     self.root.title("Simple Banking System")


     # Add a label for the heading
     heading_label = tk.Label(self.root, text="SIMPLE BANKING SYSTEM", font=("Helvetica", 16, "bold"))
     heading_label.pack(pady=10)


     # Create a frame for the options
     options_frame = tk.Frame(self.root)
     options_frame.pack()


     # Add radio buttons for user and admin options
     self.var = tk.IntVar()
     admin_radio = tk.Radiobutton(options_frame, text="Admin", variable=self.var, value=1, command=self.toggle_widgets)
     user_radio = tk.Radiobutton(options_frame, text="User", variable=self.var, value=2, command=self.toggle_widgets)


     admin_radio.grid(row=0, column=0, padx=10)
     user_radio.grid(row=0, column=1, padx=10)


     # Add entry widgets for username and password
     self.admin_username_label = tk.Label(self.root, text="Admin Username:")
     self.admin_username_entry = tk.Entry(self.root, show="*")
     self.admin_password_label = tk.Label(self.root, text="Admin Password:")
     self.admin_password_entry = tk.Entry(self.root, show="*")


     self.user_username_label = tk.Label(self.root, text="User Username:")
     self.user_username_entry = tk.Entry(self.root, show="*")
     self.user_password_label = tk.Label(self.root, text="User Password:")
     self.user_password_entry = tk.Entry(self.root, show="*")


     # Add a login button
     login_button = tk.Button(self.root, text="Login", command=self.login)
     login_button.pack(pady=20)


     screen_width = self.root.winfo_screenwidth()
     screen_height = self.root.winfo_screenheight()

     window_width = 400
     window_height = 250

     x_position = (screen_width - window_width) // 2
     y_position = (screen_height - window_height) // 2

     self.root.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


     # Start the main loop
     self.root.mainloop()


 def toggle_widgets(self):
     user_type = self.var.get()
     if user_type == 1:  # Admin
         self.user_username_label.pack_forget()
         self.user_username_entry.pack_forget()
         self.user_password_label.pack_forget()
         self.user_password_entry.pack_forget()


         self.admin_username_label.pack()
         self.admin_username_entry.pack()
         self.admin_password_label.pack()
         self.admin_password_entry.pack()
     elif user_type == 2:  # User
         self.admin_username_label.pack_forget()
         self.admin_username_entry.pack_forget()
         self.admin_password_label.pack_forget()
         self.admin_password_entry.pack_forget()


         self.user_username_label.pack()
         self.user_username_entry.pack()
         self.user_password_label.pack()
         self.user_password_entry.pack()


 def login(self):
     user_type = self.var.get()
     if user_type == 1:  # Admin
         self.admin_login()
     elif user_type == 2:  # User
         self.user_login()
     else:
         messagebox.showinfo("Error", "Invalid option selected")



 def admin_login(self):

     admin_username = self.admin_username_entry.get()
     admin_password = self.admin_password_entry.get()


     if self.authenticate_user(admin_username, admin_password, "admin"):
         self.show_admin_options()
     else:
         messagebox.showinfo("Login Failed", "Invalid username or password for Admin")



 def user_login(self):


     user_username = self.user_username_entry.get()
     user_password = self.user_password_entry.get()


     if self.authenticate_user(user_username, user_password, "user"):
         self.show_user_panel(user_username)
     else:
         messagebox.showinfo("Login Failed", "Invalid username or password for User")


 def show_user_panel(self, username):
     self.root.withdraw()  # Hide the login window


     user_panel = tk.Tk()
     user_panel.title(f"User Panel - {username}")



     screen_width = user_panel.winfo_screenwidth()
     screen_height = user_panel.winfo_screenheight()



     window_width = 400
     window_height = 250


     x_position = (screen_width - window_width) // 2
     y_position = (screen_height - window_height) // 2


     user_panel.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


     # Add a heading label for User Options
     heading_label = tk.Label(user_panel, text="User Options", font=("Helvetica", 16, "bold"))
     heading_label.pack(pady=10)


     # Add buttons for user functionalities
     update_details_button = tk.Button(user_panel, text="Update Personal Details",
                                       command=self.update_personal_details)
     check_balance_button = tk.Button(user_panel, text="Check Balance", command=self.check_balance)
     make_transaction_button = tk.Button(user_panel, text="Make Transaction", command=self.make_transaction)


     update_details_button.pack(pady=10)
     check_balance_button.pack(pady=10)
     make_transaction_button.pack(pady=10)


     # Add a Logout button
     logout_button = tk.Button(user_panel, text="Logout", command=lambda: self.logout(user_panel))
     logout_button.pack(side=tk.TOP, anchor=tk.NE, padx=10, pady=10)


     # Start the main loop for the user panel
     user_panel.mainloop()


 def update_personal_details(self):
    user_username = self.user_username_entry.get()
    user_password = self.user_password_entry.get()

    # Authenticate the user
    if self.authenticate_user(user_username, user_password, "user"):
        # Retrieve the user's data from user_data.txt
        with open('user_data.txt', 'r') as file:
            user_data = [line.strip().split(',') for line in file if line.startswith(user_username)]

        if user_data:
            user_details = user_data[0]  # Assuming user details are found

            def update_user_data():
                # Get updated user details from entry widgets
                updated_details = [entry.get() for entry in entries]

                # Update the user_data list with the new details
                for i in range(len(user_details)):
                    if i != 2 and i != len(user_details) - 1:  # Skip account number and balance
                        if i < len(updated_details):
                            user_details[i] = updated_details[i]

                # Write the updated user data back to the file
                with open('user_data.txt', 'r') as file:
                    lines = file.readlines()

                with open('user_data.txt', 'w') as file:
                    for line in lines:
                        if not line.startswith(user_username):
                            file.write(line)
                    file.write(','.join(user_details) + '\n')

                # Check if username or password has been updated
                new_username, new_password = user_details[0], user_details[1]
                if new_username != user_username or new_password != user_password:
                    with open('user_credentials.txt', 'r') as cred_file:
                        lines = cred_file.readlines()

                    with open('user_credentials.txt', 'w') as cred_file:
                        for line in lines:
                            stored_username, stored_password = line.strip().split(',')
                            if stored_username == user_username:
                                line = f"{new_username},{new_password}\n"
                            cred_file.write(line)

                messagebox.showinfo("Update Details", "User details updated successfully")
                edit_user_window.destroy()

            # Create a new window to edit user details
            edit_user_window = tk.Tk()
            edit_user_window.title("Edit Personal Details")

            labels = ["Full Name", "Password", "Email", "Contact", "Address"]
            entries = []

            for row, (label, value) in enumerate(zip(labels, user_details)):
                if row != 2:  # Skip Account Number
                    label_widget = tk.Label(edit_user_window, text=label + ":")
                    label_widget.grid(row=row, column=0, padx=10, pady=10)

                    entry_widget = tk.Entry(edit_user_window)
                    entry_widget.insert(0, value)  # Pre-fill the current value
                    entry_widget.grid(row=row, column=1, padx=10, pady=10)
                    entries.append(entry_widget)

            update_button = tk.Button(edit_user_window, text="Update", command=update_user_data)
            update_button.grid(row=len(labels), column=0, columnspan=2, pady=10)

            # Calculate the screen width and height
            screen_width = edit_user_window.winfo_screenwidth()
            screen_height = edit_user_window.winfo_screenheight()

            # Set the window size and position in the middle of the screen
            window_width = 300
            window_height = 300

            x_position = (screen_width - window_width) // 2
            y_position = (screen_height - window_height) // 2

            edit_user_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

            edit_user_window.mainloop()
        else:
            messagebox.showinfo("Update Details", "User data not found")
    else:
        messagebox.showinfo("Login Failed", "Invalid username or password for User")


 def check_balance(self):
    user_username = self.user_username_entry.get()
    user_password = self.user_password_entry.get()

    # Authenticate the user
    if self.authenticate_user(user_username, user_password, "user"):
        # Retrieve the user's data from user_data.txt
        with open('user_data.txt', 'r') as file:
            user_data = [line.strip().split(',') for line in file if line.startswith(user_username)]

        if user_data:
            user_details = user_data[0]  # Assuming user details are found

            # Fetch balance from user_details (assuming it's the last item in the list)
            balance = user_details[-1]

            # Create a new window to display balance
            balance_window = tk.Toplevel()
            balance_window.title("Your Balance")

            # Display the balance
            balance_label = tk.Label(balance_window, text=f"Your balance is: {balance}")
            balance_label.pack(padx=20, pady=10)

            # Calculate the screen width and height
            screen_width = balance_window.winfo_screenwidth()
            screen_height = balance_window.winfo_screenheight()

            # Set the window size and position in the middle of the screen
            window_width = 300
            window_height = 300

            x_position = (screen_width - window_width) // 2
            y_position = (screen_height - window_height) // 2

            balance_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

            # Set the window size and position
            balance_window.geometry("300x100")
            balance_window.resizable(False, False)
            balance_window.focus_set()
            balance_window.grab_set()

        else:
            messagebox.showinfo("Check Balance", "User data not found")
    else:
        messagebox.showinfo("Login Failed", "Invalid username or password for User")


 def make_transaction(self):
    user_username = self.user_username_entry.get()
    user_password = self.user_password_entry.get()

    # Authenticate the user
    if self.authenticate_user(user_username, user_password, "user"):
        # Hide the main window
        self.root.withdraw()

        # Create a new window for transaction
        transaction_window = tk.Tk()
        transaction_window.title("Make Transaction")

        # Function to handle the transaction
        def perform_transaction():
            receiver_username = receiver_entry.get()
            amount = float(amount_entry.get())

            # Read current user's data from file
            with open('user_data.txt', 'r') as file:
                user_data = [line.strip().split(',') for line in file if line.startswith(user_username)]

            if user_data:
                user_details = user_data[0]  # Assuming user details are found

                # Fetch balance from user_details (assuming it's the last item in the list)
                user_balance = float(user_details[-1])

                if user_balance >= amount:
                    # Read receiver's data from file
                    with open('user_data.txt', 'r') as file:
                        receiver_data = [line.strip().split(',') for line in file if line.startswith(receiver_username)]

                    if receiver_data:
                        receiver_details = receiver_data[0]  # Assuming receiver details are found

                        # Fetch balance from receiver_details (assuming it's the last item in the list)
                        receiver_balance = float(receiver_details[-1])

                        # Update balances
                        user_balance -= amount
                        receiver_balance += amount

                        # Update user's balance in file
                        with open('user_data.txt', 'r') as file:
                            lines = file.readlines()

                        with open('user_data.txt', 'w') as file:
                            for line in lines:
                                if line.startswith(user_username):
                                    line = ','.join(user_details[:-1]) + f',{user_balance}\n'
                                file.write(line)

                        # Update receiver's balance in file
                        with open('user_data.txt', 'r') as file:
                            lines = file.readlines()

                        with open('user_data.txt', 'w') as file:
                            for line in lines:
                                if line.startswith(receiver_username):
                                    line = ','.join(receiver_details[:-1]) + f',{receiver_balance}\n'
                                file.write(line)

                        messagebox.showinfo("Make Transaction", f"Transaction of {amount} successful!")
                        transaction_window.destroy()
                    else:
                        messagebox.showinfo("Make Transaction", "Receiver data not found")
                else:
                    messagebox.showinfo("Make Transaction", "Insufficient balance")
            else:
                messagebox.showinfo("Make Transaction", "User data not found")

        # Create labels and entry widgets in the transaction window
        receiver_label = tk.Label(transaction_window, text="Receiver Username:")
        receiver_label.pack()

        receiver_entry = tk.Entry(transaction_window)
        receiver_entry.pack()

        amount_label = tk.Label(transaction_window, text="Amount to Transfer:")
        amount_label.pack()

        amount_entry = tk.Entry(transaction_window)
        amount_entry.pack()

        confirm_button = tk.Button(transaction_window, text="Confirm", command=perform_transaction)
        confirm_button.pack()

        # Function to handle closing the transaction window
        def close_transaction_window():
            transaction_window.destroy()
            self.root.deiconify()  # Show the main window again

        back_button = tk.Button(transaction_window, text="Back", command=close_transaction_window)
        back_button.pack()

        # Calculate the screen width and height
        screen_width = transaction_window.winfo_screenwidth()
        screen_height = transaction_window.winfo_screenheight()

        # Set the window size and position in the middle of the screen
        window_width = 300
        window_height = 300

        x_position = (screen_width - window_width) // 2
        y_position = (screen_height - window_height) // 2

        transaction_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")

        # Start the transaction window loop
        transaction_window.mainloop()
    else:
        messagebox.showinfo("Login Failed", "Invalid username or password for User")


 def authenticate_user(self, username, password, user_type):


     filename = 'admin_credentials.txt' if user_type == "admin" else 'user_credentials.txt'


     # Read user credentials from the respective file
     with open(filename, 'r') as file:
         for line in file:
             stored_username, stored_password = line.strip().split(',')
             if username == stored_username and password == stored_password:
                 return True
     return False


 def show_admin_options(self):


     self.root.withdraw()  # Hide the login window


     # Create a new window for admin options
     admin_window = tk.Tk()
     admin_window.title("Admin Options")


     # Add a label for the heading
     heading_label = tk.Label(admin_window, text="ADMIN OPTIONS", font=("Helvetica", 16, "bold"))
     heading_label.pack(pady=10)


     # Add buttons for admin functionalities
     add_user_button = tk.Button(admin_window, text="Add User", command=self.add_user)
     view_users_button = tk.Button(admin_window, text="View Users", command=self.view_users)
     update_user_button = tk.Button(admin_window, text="Update User", command=self.update_user)
     delete_user_button = tk.Button(admin_window, text="Delete User", command=self.delete_user)
     search_user_button = tk.Button(admin_window, text="Search User", command=self.search_user)


     add_user_button.pack(pady=10)
     view_users_button.pack(pady=10)
     update_user_button.pack(pady=10)
     delete_user_button.pack(pady=10)
     search_user_button.pack(pady=10)


     # Add a Logout button
     logout_button = tk.Button(admin_window, text="Logout", command=lambda: self.logout(admin_window))
     logout_button.pack(side=tk.TOP, anchor=tk.NE, padx=10, pady=10)


     # Calculate the screen width and height
     screen_width = admin_window.winfo_screenwidth()
     screen_height = admin_window.winfo_screenheight()


     # Set the window size and position in the middle of the screen
     window_width = 500
     window_height = 320

     x_position = (screen_width - window_width) // 2
     y_position = (screen_height - window_height) // 2

     admin_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


     # Start the main loop for the admin window
     admin_window.mainloop()


 def logout(self, admin_window):
     # Destroy the admin window and show the main login window
     admin_window.destroy()
     self.root.deiconify()


 def add_user(self):

  add_user_window = tk.Tk()
  add_user_window.title("Add User")


  # Labels and entry widgets for user details
  labels = ["Full Name", "Password", "Account Number", "Email", "Contact", "Address", "Balance"]
  entries = []


  for row, label in enumerate(labels):
      label_widget = tk.Label(add_user_window, text=label + ":")
      label_widget.grid(row=row, column=0, padx=10, pady=10)


      entry_widget = tk.Entry(add_user_window)
      entry_widget.grid(row=row, column=1, padx=10, pady=10)
      entries.append(entry_widget)


  # Function to handle adding user data
  def add_new_user():
      # Check if any field is empty
      if not all(entry.get() for entry in entries):
          messagebox.showerror("Error", "Please fill all the fields")
          return


      user_data = [entry.get() for entry in entries]
      self.users.append(user_data)


      # Write user data to file
      with open('user_data.txt', 'a') as file:
          file.write(','.join(user_data) + '\n')


      # Copy full name and password to user_credentials.txt
      with open('user_credentials.txt', 'a') as credentials_file:
          credentials_file.write(f"{user_data[0]},{user_data[1]}\n")


      messagebox.showinfo("Add User", "User added successfully")
      add_user_window.destroy()


  # Button to add a new user
  add_button = tk.Button(add_user_window, text="Add User", command=add_new_user)
  add_button.grid(row=len(labels), column=0, columnspan=2, pady=10)


  # Back button to return to admin options
  back_button = tk.Button(add_user_window, text="Back", command=add_user_window.destroy)
  back_button.grid(row=len(labels) + 1, column=0, columnspan=2, pady=10)


  # Calculate the screen width and height
  screen_width = add_user_window.winfo_screenwidth()
  screen_height = add_user_window.winfo_screenheight()


  # Set the window size and position in the middle of the screen
  window_width = 500
  window_height = 380


  x_position = (screen_width - window_width) // 2
  y_position = (screen_height - window_height) // 2


  add_user_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


  add_user_window.mainloop()


 def view_users(self):


     # Read user data from file
     with open('user_data.txt', 'r') as file:
         user_data = [line.strip().split(',') for line in file]


     view_users_window = tk.Tk()
     view_users_window.title("View Users")


     # Create a frame for displaying users
     users_frame = tk.Frame(view_users_window)
     users_frame.pack()


     # Headings for user data
     headings = ["Full Name", "Password", "Account Number", "Email", "Contact", "Address", "Balance"]


     # Display headings
     for col, heading in enumerate(headings):
         label = tk.Label(users_frame, text=heading, font=("Helvetica", 10, "bold"))
         label.grid(row=0, column=col, padx=5, pady=5)


     # Display user data
     for row, user in enumerate(user_data, start=1):
         for col, value in enumerate(user):
             label = tk.Label(users_frame, text=value)
             label.grid(row=row, column=col, padx=5, pady=5)


     # Back button to return to admin options
     back_button = tk.Button(view_users_window, text="Back", command=view_users_window.destroy)
     back_button.pack(pady=10)

     # Calculate the screen width and height
     screen_width = view_users_window.winfo_screenwidth()
     screen_height = view_users_window.winfo_screenheight()

     # Set the window size and position in the middle of the screen
     window_width = 650
     window_height = 380

     x_position = (screen_width - window_width) // 2
     y_position = (screen_height - window_height) // 2

     view_users_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


     view_users_window.mainloop()


 def update_user(self):


  update_user_window = tk.Tk()
  update_user_window.title("Update User")


  # Label and entry widget for specifying the account number to update
  account_number_label = tk.Label(update_user_window, text="Account Number:")
  account_number_label.grid(row=0, column=0, padx=10, pady=10)


  account_number_entry = tk.Entry(update_user_window)
  account_number_entry.grid(row=0, column=1, padx=10, pady=10)


  # Function to handle updating user data
  def confirm_update():
      account_number_to_update = account_number_entry.get().strip()


      # Read current user data from file
      with open('user_data.txt', 'r') as file:
          user_data = [line.strip().split(',') for line in file]


      # Find the user by account number
      user_to_update = None
      for user in user_data:
          if user[2] == account_number_to_update:
              user_to_update = user
              break


      # If the user is found, allow the admin to update details
      if user_to_update:
          update_user_details_window = tk.Tk()
          update_user_details_window.title("Update User Details")


          # Labels and entry widgets for user details
          labels = ["Full Name", "Password", "Account Number", "Email", "Contact", "Address", "Balance"]
          entries = []


          for row, (label, value) in enumerate(zip(labels, user_to_update)):
              label_widget = tk.Label(update_user_details_window, text=label + ":")
              label_widget.grid(row=row, column=0, padx=10, pady=10)


              entry_widget = tk.Entry(update_user_details_window)
              entry_widget.insert(0, value)  # Pre-fill the current value
              entry_widget.grid(row=row, column=1, padx=10, pady=10)
              entries.append(entry_widget)


          # Function to handle updating user data
          def update_user_data():
              updated_user_data = [entry.get() for entry in entries]


              # Update the user_data list with the new details
              user_data[user_data.index(user_to_update)] = updated_user_data


              # Write the updated user data back to the file
              with open('user_data.txt', 'w') as file:
                  for user_entry in user_data:
                      file.write(','.join(user_entry) + '\n')


              # Check if username or password has been updated
              new_username, new_password = updated_user_data[0], updated_user_data[1]
              if new_username != user_to_update[0] or new_password != user_to_update[1]:
                  with open('user_credentials.txt', 'r') as cred_file:
                      lines = cred_file.readlines()


                  with open('user_credentials.txt', 'w') as cred_file:
                      for line in lines:
                          stored_full_name, stored_password = line.strip().split(',')
                          if stored_full_name == user_to_update[0]:
                              line = f"{new_username},{new_password}\n"
                          cred_file.write(line)


              messagebox.showinfo("Update User", "User data updated successfully")


              update_user_details_window.destroy()


          # Button to update user details
          update_button = tk.Button(update_user_details_window, text="Update User", command=update_user_data)
          update_button.grid(row=len(labels), column=0, columnspan=2, pady=10)


          # Back button to close the update window
          back_button = tk.Button(update_user_details_window, text="Back",
                                  command=update_user_details_window.destroy)
          back_button.grid(row=len(labels) + 1, column=0, columnspan=2, pady=10)


          update_user_details_window.mainloop()
      else:
          messagebox.showerror("Error", "User not found")


      update_user_window.destroy()


  # Button to confirm updating user
  update_button = tk.Button(update_user_window, text="Update", command=confirm_update)
  update_button.grid(row=1, column=0, columnspan=2, pady=10)


  # Back button to return to admin options
  back_button = tk.Button(update_user_window, text="Back", command=update_user_window.destroy)
  back_button.grid(row=2, column=0, columnspan=2, pady=10)


  # Calculate the screen width and height
  screen_width = update_user_window.winfo_screenwidth()
  screen_height = update_user_window.winfo_screenheight()


  # Set the window size and position in the middle of the screen
  window_width = 300
  window_height = 300


  x_position = (screen_width - window_width) // 2
  y_position = (screen_height - window_height) // 2


  update_user_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


  update_user_window.mainloop()


 def delete_user(self):


  delete_user_window = tk.Tk()
  delete_user_window.title("Delete User")


  # Label and entry widget for specifying the account number to delete
  account_number_label = tk.Label(delete_user_window, text="Account Number:")
  account_number_label.grid(row=0, column=0, padx=10, pady=10)


  account_number_entry = tk.Entry(delete_user_window)
  account_number_entry.grid(row=0, column=1, padx=10, pady=10)


  # Function to handle the deletion of user data
  def confirm_delete():
      account_number_to_delete = account_number_entry.get().strip()


      # Read current user data from file
      with open('user_data.txt', 'r') as file:
          user_data = [line.strip().split(',') for line in file]


      # Find the user by account number
      user_to_delete = None
      for user in user_data:
          if user[2] == account_number_to_delete:
              user_to_delete = user
              break


      # If the user is found, confirm the deletion
      if user_to_delete:
          confirmation_message = f"Are you sure that you want to delete the data for {user_to_delete[0]}?"
          confirmation = messagebox.askyesno("Confirm Deletion", confirmation_message)


          if confirmation:
              # Remove the user from the user_data list
              user_data.remove(user_to_delete)


              # Write the updated user data back to the file
              with open('user_data.txt', 'w') as file:
                  for user_entry in user_data:
                      file.write(','.join(user_entry) + '\n')


              # Remove corresponding full name and password from user_credentials.txt
              with open('user_credentials.txt', 'r') as credentials_file:
                  lines = credentials_file.readlines()


              with open('user_credentials.txt', 'w') as credentials_file:
                  for line in lines:
                      stored_full_name, stored_password = line.strip().split(',')
                      if stored_full_name != user_to_delete[0]:
                          credentials_file.write(line)


              messagebox.showinfo("Delete User", "User data deleted successfully")
          else:
              messagebox.showinfo("Delete User", "Deletion canceled")
      else:
          messagebox.showerror("Error", "User not found")


      delete_user_window.destroy()


  # Button to confirm deletion
  delete_button = tk.Button(delete_user_window, text="Delete", command=confirm_delete)
  delete_button.grid(row=1, column=0, columnspan=2, pady=10)


  # Back button to return to admin options
  back_button = tk.Button(delete_user_window, text="Back", command=delete_user_window.destroy)
  back_button.grid(row=2, column=0, columnspan=2, pady=10)


  # Calculate the screen width and height
  screen_width = delete_user_window.winfo_screenwidth()
  screen_height = delete_user_window.winfo_screenheight()


  # Set the window size and position in the middle of the screen
  window_width = 300
  window_height = 300


  x_position = (screen_width - window_width) // 2
  y_position = (screen_height - window_height) // 2


  delete_user_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


  delete_user_window.mainloop()


 def search_user(self):


     search_user_window = tk.Tk()
     search_user_window.title("Search User")


     # Label and entry widget for specifying the data to search
     search_label = tk.Label(search_user_window, text="Search Data:")
     search_label.grid(row=0, column=0, padx=10, pady=10)


     search_entry = tk.Entry(search_user_window)
     search_entry.grid(row=0, column=1, padx=10, pady=10)


     # Function to handle searching for user data
     def perform_search():
         search_data = search_entry.get().strip()


         def display_user_data(user):
             user_data_window = tk.Tk()
             user_data_window.title("User Data")


             # Headings and values for user data
             headings = ["Full Name", "Password", "Account Number", "Email", "Contact", "Address", "Balance"]


             for row, (heading, value) in enumerate(zip(headings, user)):
                 label_heading = tk.Label(user_data_window, text=heading, font=("Helvetica", 10, "bold"))
                 label_heading.grid(row=row, column=0, padx=10, pady=5)


                 label_value = tk.Label(user_data_window, text=value)
                 label_value.grid(row=row, column=1, padx=10, pady=5)


             # Back button to close the user data window
             back_button = tk.Button(user_data_window, text="Back", command=user_data_window.destroy)
             back_button.grid(row=row + 1, column=0, columnspan=2, pady=10)


             # Calculate the screen width and height
             screen_width = user_data_window.winfo_screenwidth()
             screen_height = user_data_window.winfo_screenheight()


             # Set the window size and position in the middle of the screen
             window_width = 300
             window_height = 400


             x_position = (screen_width - window_width) // 2
             y_position = (screen_height - window_height) // 2


             user_data_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


             user_data_window.mainloop()


         # Read current user data from file
         with open('user_data.txt', 'r') as file:
             user_data = [line.strip().split(',') for line in file]


         # Find the user by account number or other specified data
         user_found = False
         for user in user_data:
             if search_data == user[0] or search_data == user[2]:  # Assuming search by full name or account number
                 user_found = True
                 break


         # If the user is found, display the user's data
         if user_found:
             display_user_data(user)
         else:
             messagebox.showerror("Error", "User not found")


         search_user_window.destroy()


     # Button to perform the search
     search_button = tk.Button(search_user_window, text="Search", command=perform_search)
     search_button.grid(row=1, column=0, columnspan=2, pady=10)


     # Back button to return to admin options
     back_button = tk.Button(search_user_window, text="Back", command=search_user_window.destroy)
     back_button.grid(row=2, column=0, columnspan=2, pady=10)


     # Calculate the screen width and height
     screen_width = search_user_window.winfo_screenwidth()
     screen_height = search_user_window.winfo_screenheight()


     # Set the window size and position in the middle of the screen
     window_width = 300
     window_height = 300


     x_position = (screen_width - window_width) // 2
     y_position = (screen_height - window_height) // 2


     search_user_window.geometry(f"{window_width}x{window_height}+{x_position}+{y_position}")


     search_user_window.mainloop()


# Instantiate the SimpleBankingSystem class and run the application
banking_system = SimpleBankingSystem()
banking_system.run()