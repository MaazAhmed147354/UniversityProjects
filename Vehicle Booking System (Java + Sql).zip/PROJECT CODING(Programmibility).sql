----------Customer----------
---1
CREATE PROCEDURE InsertCustomerRecord
	@CNIC varchar(15),
	@Name varchar(20),
	@PhNo varchar(11),
	@Uname varchar(50),
	@Pass varchar(50)
AS 
BEGIN	
	INSERT INTO Customer(CustomerCNIC, CustomerName, PhoneNo, Username, Password) 
	VALUES(@CNIC, @Name, @PhNo, @Uname, @Pass)
END
---2
CREATE PROCEDURE MatchCustomerUsernamePassword
    @Uname varchar(50),
    @Pass varchar(50)
AS 
BEGIN
    SELECT * FROM Customer
    WHERE Username = @Uname AND Password = @Pass;
END
--3
CREATE PROCEDURE GetCustomerDetailsByCNIC
    @CNIC varchar(15)
AS 
BEGIN
    SELECT CustomerName, PhoneNo, Password
    FROM Customer
    WHERE CustomerCNIC = @CNIC;
END
--4
CREATE PROCEDURE UpdateCustomerDetails
    @CNIC varchar(15),
    @Name varchar(20),
    @PhNo varchar(11),
    @Pass varchar(50)
AS 
BEGIN
    UPDATE Customer
    SET CustomerName = @Name, PhoneNo = @PhNo, Password = @Pass, Username = @Name
    WHERE CustomerCNIC = @CNIC;
END
---5
CREATE TRIGGER trg_Customer
ON Customer
AFTER INSERT
AS
BEGIN
    
    IF EXISTS (SELECT 1 FROM inserted WHERE CustomerCNIC NOT LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'
                                     OR PhoneNo NOT LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
    BEGIN
  
        ROLLBACK TRANSACTION;
        RAISERROR('Invalid data! CustomerCNIC and PhoneNo must be numeric.', 16, 1);
    END
    ELSE
    BEGIN
        INSERT INTO CustomerLog (CustomerCNIC, CustomerName, PhoneNo, Username, Password)
        SELECT i.CustomerCNIC, i.CustomerName, i.PhoneNo, i.Username, i.Password
        FROM inserted i;
    END
END
---6
CREATE FUNCTION GetCustomerBookingHistory(@CNIC varchar(13))
RETURNS TABLE
AS
RETURN(SELECT * FROM Booking Where CustomerCNIC = @CNIC)

----------Driver----------
---1
CREATE PROCEDURE InsertDriverRecord
	@CNIC varchar(15),
	@Name varchar(20),
	@PhNo varchar(11),
	@LicNo varchar(17),
	@Uname varchar(50),
	@Pass varchar(50)
AS 
BEGIN	
	INSERT INTO Driver(DriverCNIC, DriverName, PhoneNo, Licenseno, Availibility, Username, Password) 
	VALUES(@CNIC, @Name, @PhNo, @LicNo, 'Yes', @Uname, @Pass)
END
---2
CREATE PROCEDURE MatchDriverUsernamePassword
    @Uname varchar(50),
    @Pass varchar(50)
AS 
BEGIN
    SELECT * FROM Driver
    WHERE Username = @Uname AND Password = @Pass;
END
---3
CREATE PROCEDURE GetDriverDetailsByCNIC
    @CNIC varchar(15)
AS 
BEGIN
    SELECT DriverName, PhoneNo, LicenseNo, Availibility , Password
    FROM Driver
    WHERE DriverCNIC = @CNIC;
END
---4
CREATE PROCEDURE UpdateDriverDetails
    @CNIC varchar(15),
	@Name varchar(20),
	@PhNo varchar(11),
	@LicNo varchar(17),
	@Pass varchar(50)
AS 
BEGIN
    UPDATE Driver
    SET DriverName = @Name, PhoneNo = @PhNo, LicenseNo = @LicNo, Password = @Pass, Username = @Name
    WHERE DriverCNIC = @CNIC;
END
---5
CREATE FUNCTION GetDriverBookingHistory(@CNIC varchar(13))
RETURNS TABLE
AS
RETURN(SELECT * FROM Booking Where DriverCNIC = @CNIC)
---6
CREATE TRIGGER trg_Driver_Insert
ON Driver
AFTER INSERT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM inserted WHERE DriverCNIC NOT LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'
                                     OR LicenseNo NOT LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]#[0-9][0-9][0-9]'
                                     OR PhoneNo NOT LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR('Invalid data!', 16, 1);
    END
END
----------Vehicle----------
---1
CREATE PROCEDURE RegisterVehicle
    @CNIC varchar(15),
    @LicPtNo varchar(6),
    @Make varchar(10),
    @Model varchar(15),
    @Cap int,
    @VType varchar(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Driver WHERE DriverCNIC = @CNIC)
    BEGIN
        INSERT INTO Vehicle (LicensePlateNo, Make, Model, Capacity, DriverCNIC, VehicleType)
        VALUES (@LicPtNo, @Make, @Model, @Cap, @CNIC, @VType);
        
        -- Optionally, you can return a success message for each vehicle added
        SELECT 'Vehicle added successfully for CNIC: ' + @CNIC + '.' AS Result;
    END
    ELSE
    BEGIN
        RAISERROR ('Driver with CNIC %s does not exist.', 16, 1, @CNIC);
        RETURN;
    END
END
----------VehicleCategory----------
---1
Insert Into VehicleCategory(VehicleType, BaseFare, FarePerKm)
Values('Bike', 30, 5), ('Car', 80, 20), ('MiniCar', 60, 12)
----------Locations----------
---1
Insert Into Locations(LocID, Area, StopNo, CoordinateX, CoordinateY)
Values(1, 'Gulshan', 1, 1, 1), (2, 'Gulshan', 2, 2, 2), 
(3, 'Pechs', 1, 3, 3), (4, 'Pechs', 2, 4, 4), 
(5, 'Defence', 1, 5, 5), (6, 'Defence', 2, 6, 6), 
(7, 'Nazimabad', 1, 7, 7), (8, 'Nazimabad', 2, 8, 8)
---2
CREATE PROCEDURE GetCordinateByAreaAndStop
    @area varchar(20),
	@stopNo int
AS 
BEGIN
    SELECT CoordinateX, CoordinateY
    FROM Locations
    WHERE Area = @area AND StopNo = @stopNo
END
---2
CREATE PROCEDURE InsertDropOffLoc
    @DropOffID INT,
    @LocID INT
AS
BEGIN
    INSERT INTO DropOffLoc (DropOffID, LocID)
    VALUES (@DropOffID, @LocID)
END
Exec InsertDropOffLoc 1,5
Select * From DropOffLoc
---3
CREATE PROCEDURE InsertPickUpLoc
    @PickupID INT,
    @LocID INT
AS
BEGIN
    INSERT INTO PickUpLoc (PickUpID, LocID)
    VALUES (@PickupID, @LocID)
END
Exec InsertPickUpLoc 1,2
Select * From PickUpLoc
----------Trip----------
---1
CREATE PROCEDURE InsertTrip
    @TripID INT,
    @PickUpID INT,
    @DropOffID INT,
    @Distance NUMERIC(10,2)
AS
BEGIN
    INSERT INTO Trip (TripID, PickUpID, DropOffID, Distance)
    VALUES (@TripID, @PickUpID, @DropOffID, @Distance);
END
Exec InsertTrip 1,1,1,14
Select * From Trip
----------Fare----------
---1
CREATE PROCEDURE InsertFareCalculation
    @FareID INT,
    @VehicleType VARCHAR(10),
    @TripID INT,
    @Fare INT
AS
BEGIN
    INSERT INTO FareCalculation (FareID, VehicleType, TripID, Fare)
    VALUES (@FareID, @VehicleType, @TripID, @Fare)
END
Exec InsertFareCalculation 1,'Bike',1,100
Select * From FareCalculation
----------PaymentMethod----------
---1
CREATE PROCEDURE InsertPaymentMethod
    @PayMtdID INT,
    @Mtd VARCHAR(10)
AS
BEGIN
    INSERT INTO PaymentMethod(PaymentMethodID, Method)
    VALUES (@PayMtdID, @Mtd)
END
Exec InsertPaymentMethod 1,'Cash'
Exec InsertPaymentMethod 2,'CreditCard'
Select * From PaymentMethod
----------Payment----------
---1
CREATE PROCEDURE InsertPayment
    @PayID int,
	@PayMtdID int,
    @PayStat varchar(10)
AS
BEGIN
    INSERT INTO Payment(PaymentID, PaymentMethodID, PaymentStatus)
    VALUES (@PayID, @PayMtdID, @PayStat)
END
Exec InsertPayment 1,2,'NotPaid'
Exec InsertPayment 2,1,'Paid'
Select * From Payment
----------BookingStatus----------
---1
CREATE PROCEDURE InsertBookingStatus
    @StatID INT,
    @BkStat VARCHAR(10)
AS
BEGIN
    INSERT INTO BookingStatus(StatusID, BookStatus)
    VALUES (@StatID, @BkStat)
END
Exec InsertBookingStatus 1,'Requested'
Exec InsertBookingStatus 2,'Cancelled'
Exec InsertBookingStatus 3,'Ongoing'
Exec InsertBookingStatus 4,'Completed'
Select * From BookingStatus
----------Review----------
---1
CREATE PROCEDURE InsertReview
    @RevID int,
	@Comm varchar(50),
    @Rat int
AS
BEGIN
    INSERT INTO Review(ReviewID, Comment, Rating)
    VALUES (@RevID, @Comm, @Rat)
END
Exec InsertReview 1,'Excellent',5
Select * From Review
----------Booking----------
---1
CREATE PROCEDURE InsertBooking
    @BkID int,
	@TripID int,
    @CCnic varchar(13),
	@DCnic varchar(13),
	@FareID int,
	@StatID int,
	@PayID int,
	@RevID int
AS
BEGIN
	DECLARE @BkDate date
	DECLARE @BkTime time
	SET @BkDate=(SELECT CONVERT(date, GETDATE()))
	SET @BkTime=(SELECT CONVERT(varchar(12), GETDATE(), 108))
    INSERT INTO Booking(BookingID, TripID, CustomerCNIC, DriverCNIC, 
	FareID, StatusID, PaymentID, ReviewID, BookingDate, BookingTime)
    VALUES (@BkID, @TripID, @CCnic, @DCnic, @FareID, @StatID, @PayID, @RevID, @BkDate, @BkTime)
END
Exec InsertBooking 1,1,'1234512345671','1234512345671',1,1,2,1
Select * From Booking