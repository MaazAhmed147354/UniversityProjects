--1
Create Table Customer(CustomerCNIC varchar(13), CustomerName varchar(20) Not Null, 
PhoneNo varchar(11) Not Null, Username varchar(50), Password varchar(50), 
Constraint pk_Customer Primary Key(CustomerCNIC), 
Constraint ck_ccnic Check (CustomerCNIC LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), 
Constraint ck_cphoneno Check (PhoneNo LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), 
Constraint ck_cname Check (CustomerName NOT LIKE '%[^A-Za-z ]%'))
--2
Create Table VehicleCategory(VehicleType varchar(10), BaseFare int Not Null, FarePerKm int Not Null, 
Constraint pk_VehicleCategory Primary Key(VehicleType))
--3
Create Table Driver(DriverCNIC varchar(13), DriverName varchar(20) Not Null, 
PhoneNO varchar(11) Not Null, LicenseNo varchar(17) Not Null, 
Availibility varchar(3) Not Null, Username varchar(50), Password varchar(50), 
Constraint pk_Driver Primary Key(DriverCNIC),  
Constraint ck_dcnic Check (DriverCNIC LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), 
Constraint ck_license Check (LicenseNo LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]#[0-9][0-9][0-9]'), 
Constraint ck_dphoneno Check (PhoneNo LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), 
Constraint ck_dname Check (DriverName NOT LIKE '%[^A-Za-z ]%'), 
Constraint ck_availibility Check (Availibility='Yes' OR Availibility='No'))
--4
Create Table Vehicle(LicensePlateNo varchar(6), Make varchar(10) Not Null, 
Model varchar(15) Not Null, Capacity int Not Null, DriverCNIC varchar(13) , VehicleType varchar(10), 
Constraint pk_Vehicle Primary Key(LicensePlateNo),  
Constraint fk_Vehicle1 Foreign Key(VehicleType) References VehicleCategory(VehicleType),
Constraint fk_Vehicle2 Foreign Key(DriverCNIC) References Driver(DriverCNIC),
Constraint ck_licenseplateno Check (LicensePlateNo LIKE '[A-Z][A-Z][A-Z][0-9][0-9][0-9]'))
--5
Create Table Locations(LocID int, Area varchar(20) Not Null, StopNo int Not Null, 
CoordinateX int Not Null, CoordinateY int Not Null 
Constraint pk_Locations Primary Key(LocID), 
Constraint ck_area Check (Area NOT LIKE '%[^A-Za-z]%'))
--6
Create Table DropOffLoc(DropOffID int, LocID int, 
Constraint pk_DropOffLoc Primary Key(DropOffID), 
Constraint fk_DropOffLoc Foreign Key(LocID) References Locations(LocID))
--7
Create Table PickUpLoc(PickUpID int, LocID int, 
Constraint pk_PickUpLoc Primary Key(PickUpID), 
Constraint fk_PickUpLoc Foreign Key(LocID) References Locations(LocID))
--8
Create Table Trip(TripID int, PickUpID int, DropOffID int, Distance numeric(10,2), 
Constraint pk_Trip Primary Key(TripID), 
Constraint fk_Trip1 Foreign Key(PickUpID) References PickUpLoc(PickUpID), 
Constraint fk_Trip2 Foreign Key(DropOffID) References DropOffLoc(DropOffID))
--9
Create Table FareCalculation(FareID int, VehicleType varchar(10), TripID int, Fare int, 
Constraint pk_Fare Primary Key(FareID), 
Constraint fk_Fare1 Foreign Key(VehicleType) References VehicleCategory(VehicleType), 
Constraint fk_Fare2 Foreign Key(TripID) References Trip(TripID))
--10
Create Table BookingStatus(StatusID int, BookStatus varchar(10), 
Constraint pk_BookingStatus Primary Key(StatusID))
--11
Create Table PaymentMethod(PaymentMethodID int, Method varchar(10), 
Constraint pk_PaymentMethod Primary Key(PaymentMethodID))
--12
Create Table Payment(PaymentID int, PaymentMethodID int, PaymentStatus varchar(10), 
Constraint pk_Payment Primary Key(PaymentID),  
Constraint fk_Payment1 Foreign Key(PaymentMethodID) References PaymentMethod(PaymentMethodID))
--13
Create Table Review(ReviewID int, Comment varchar(50), Rating int Not Null, 
Constraint pk_Review Primary Key(ReviewID),  
Constraint ck_Rating Check (Rating>=1 AND Rating<=5))
--14
Create Table Booking(BookingID int, TripID int, CustomerCNIC varchar(13), DriverCNIC varchar(13), 
FareID int, StatusID int, PaymentID int, ReviewID int, BookingDate date Not Null, BookingTime time Not Null, 
Constraint pk_Booking Primary Key(BookingID), 
Constraint fk_Booking1 Foreign Key(TripID) References Trip(TripID), 
Constraint fk_Booking2 Foreign Key(CustomerCNIC) References Customer(CustomerCNIC), 
Constraint fk_Booking3 Foreign Key(DriverCNIC) References Driver(DriverCNIC), 
Constraint fk_Booking4 Foreign Key(FareID) References FareCalculation(FareID), 
Constraint fk_Booking5 Foreign Key(StatusID) References BookingStatus(StatusID), 
Constraint fk_Booking7 Foreign Key(PaymentID) References Payment(PaymentID), 
Constraint fk_Booking6 Foreign Key(ReviewID) References Review(ReviewID))