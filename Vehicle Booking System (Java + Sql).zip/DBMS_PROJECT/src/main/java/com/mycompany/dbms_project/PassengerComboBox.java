package com.mycompany.dbms_project;

import java.sql.*;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

public class PassengerComboBox {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    ResultSet res=null;
    
    public void InsertInAreaComboBox(JComboBox<String> comboBox){
        try {
            // SQL query to retrieve data from table
            String sql = "SELECT Area FROM Locations";
            
            // Create a prepared statement
            pstmt = con_obj.prepareStatement(sql);
            
            // Execute the query
            res = pstmt.executeQuery();
            
            // Create a DefaultComboBoxModel
            DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>();
            
            // Iterate over the result set and add items to the ComboBox model
            while (res.next()) {
                String area = res.getString("Area");
                comboBoxModel.addElement(area);
            }
            
            // Set the ComboBox model
            comboBox.setModel(comboBoxModel);
            
            // Close the result set, statement, and connection
            res.close();
            pstmt.close();
            con_obj.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void InsertInStopComboBox(JComboBox<String> comboBox){
        try {
            // SQL query to retrieve data from table
            String sql = "SELECT StopNo FROM Locations";
            
            // Create a prepared statement
            pstmt = con_obj.prepareStatement(sql);
            
            // Execute the query
            res = pstmt.executeQuery();
            
            // Create a DefaultComboBoxModel
            DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<>();
            
            // Iterate over the result set and add items to the ComboBox model
            while (res.next()) {
                String stopno = res.getString("StopNo");
                comboBoxModel.addElement(stopno);
            }
            
            // Set the ComboBox model
            comboBox.setModel(comboBoxModel);
            
            // Close the result set, statement, and connection
            res.close();
            pstmt.close();
            con_obj.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
        
}
