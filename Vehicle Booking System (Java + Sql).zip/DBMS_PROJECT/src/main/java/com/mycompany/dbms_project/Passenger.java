package com.mycompany.dbms_project;

import java.sql.*;
import javax.swing.JOptionPane;

public class Passenger {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    ResultSet res=null;
        
    String Name,Pass,Phn;
    int corx1, corx2, cory1, cory2, pid, did;
    
    public boolean signup(String FullName,String Cnic, String PhoneNo, String Password) throws SQLException{
        boolean b = false;
        String icnic = Cnic;
        String iname = FullName;
        String iphoneNo = PhoneNo;
        String ipass = Password;

        try(CallableStatement istmt = con_obj.prepareCall("{call InsertCustomerRecord(?, ?, ?, ?, ?)}")){
            
            istmt.setString(1, icnic);
            istmt.setString(2, iname);
            istmt.setString(3, iphoneNo);
            istmt.setString(4, iname);
            istmt.setString(5, ipass);

            istmt.execute();
            b=true;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        return b;
    }
    
    public boolean signin(String Username, String Password){
        boolean b = false;
        String iuname = Username;
        String ipass = Password;

        try (CallableStatement stmt2 = con_obj.prepareCall("{call MatchCustomerUsernamePassword(?, ?)}")) {

            stmt2.setString(1, iuname);
            stmt2.setString(2, ipass);

            ResultSet resultSet = stmt2.executeQuery();

            if (resultSet.next()) {
                System.out.println("Username and password matched.");
                b = true;
            } else {
                 JOptionPane.showMessageDialog(null, "Invalid username or password.");
                 b = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        return b;
    }
    
    public boolean customer(String cnic){
        boolean b = false;
        try (CallableStatement stmt3 = con_obj.prepareCall("{call GetCustomerDetailsByCNIC(?)}")) {
            
            stmt3.setString(1, cnic);

            ResultSet resultSet = stmt3.executeQuery();

            if (resultSet.next()) {
                Name = resultSet.getString("CustomerName");
                Phn = resultSet.getString("PhoneNo");
                Pass = resultSet.getString("Password");
                b = true;
            } else {
                JOptionPane.showMessageDialog(null, "No customer found with the given CNIC.");
                b = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean updateCustomer(String name, String cnic, String phn, String pass){
        boolean b = false;
        String ucnic = cnic;
        String uname = name;
        String uphoneNo = phn;
        String upass = pass;

        try (CallableStatement stmt4 = con_obj.prepareCall("{call UpdateCustomerDetails(?, ?, ?, ?)}")) {

            stmt4.setString(1, ucnic);
            stmt4.setString(2, uname);
            stmt4.setString(3, uphoneNo);
            stmt4.setString(4, upass);

            int rowsAffected = stmt4.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Customer details updated successfully.");
                b = true;
            } else {
                JOptionPane.showMessageDialog(null, "No customer found with the given CNIC.");
                b = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean getFare1(String area, int stop){
        boolean b = false;
        try{
            String sql = "{CALL GetCordinateByAreaAndStop(?, ?)}";
            CallableStatement stmt6 = con_obj.prepareCall(sql);

            stmt6.setString(1, area);
            stmt6.setInt(2, stop); 

            ResultSet rs = stmt6.executeQuery();

            while (rs.next()) {
                corx1 = rs.getInt("CoordinateX");
                cory1= rs.getInt("CoordinateY");
                pid = rs.getInt("LocID");
                b = true;    
            }

            // Close the resources
            rs.close();
            stmt6.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean getFare2(String area, int stop){
        boolean b = false;
        try{
            String sql = "{CALL GetCordinateByAreaAndStop(?, ?)}";
            CallableStatement stmt7 = con_obj.prepareCall(sql);

            stmt7.setString(1, area);
            stmt7.setInt(2, stop); 

            ResultSet rs = stmt7.executeQuery();

            while (rs.next()) {
                corx2 = rs.getInt("CoordinateX");
                cory2= rs.getInt("CoordinateY");
                did = rs.getInt("LocID");
                b = true;    
            }

            // Close the resources
            rs.close();
            stmt7.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean rideRecord(int DOI, int LI){
        boolean b = false;
        String sql = "{CALL InsertDropOffLoc(?, ?)}";
        try (CallableStatement stmt8 = con_obj.prepareCall(sql)) {
                stmt8.setInt(1, DOI); 
                stmt8.setInt(2, LI); 

                stmt8.execute();
                b = true;
            }
         catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean rideRecord2(int PUI, int LI){
        boolean b = false;
        String sql = "{CALL InsertPickOfLoc(?, ?)}";
        try (CallableStatement stmt9 = con_obj.prepareCall(sql)) {
                stmt9.setInt(1, PUI); 
                stmt9.setInt(2, LI); 

                stmt9.execute();
                b = true;
           }
         catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean tripRecordAdd(int trid, int pickid, int dropid, double dis){
        boolean b = false;
        
        String sql = "CALL InsertTrip(?, ?, ?, ?)";
        try{    
            PreparedStatement stmt10 = con_obj.prepareStatement(sql);

            stmt10.setInt(1, trid);
            stmt10.setInt(2, pickid); 
            stmt10.setInt(3, dropid); 
            stmt10.setDouble(4, dis);
            
            stmt10.execute();
            b = true;
            JOptionPane.showMessageDialog(null, "Error here");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return b;
    }
    
    public boolean fairRecord(int frid, String vtype, int tripid, int fare){
        boolean b = false;
        String sql = "{CALL InsertFareCalculation(?, ?, ?, ?)}";
        try {            
            CallableStatement stmt11 = con_obj.prepareCall(sql);

            stmt11.setInt(1, frid);
            stmt11.setString(2, vtype);
            stmt11.setInt(3, tripid);
            stmt11.setInt(4, fare);

            stmt11.execute();
            b = true;
            System.out.println("Procedure executed successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return b;
    }
}