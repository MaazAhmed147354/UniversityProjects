package com.mycompany.dbms_project;

public class DBMS_Project {

    public static void main(String[] args) {
        //ConnectionToDB con_obj = new ConnectionToDB();
        //con_obj.EstablishConnection();
        Start st = new Start();
        st.setVisible(true);
    }
}
