package com.mycompany.dbms_project;

import java.sql.*;
import javax.swing.JOptionPane;

public class ConnectionToDB {
    
    Connection conn=null;
    
    public Connection EstablishConnection() {
       try{ 
            String hostname = "localhost";
            String sqlInstanceName = "DESKTOP-5VI1ON9"; //computer name 
            String sqlDatabase = "VehicleBookingApp";  //sql server database name
            String sqlUser = "myuser";
            String sqlPassword = "pass"; //passwrod myuser account

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            //jdbc:sqlserver://localhost:1433;instance=COMPUTERBERRY;databaseName=Database;
            String connectURL = "jdbc:sqlserver://" + hostname + ":1433" 
                    + ";instance=" + sqlInstanceName + ";databaseName=" + sqlDatabase +
                    ";encrypt=true;trustServerCertificate=true";

            conn = DriverManager.getConnection(connectURL, sqlUser, sqlPassword);
            //conn = DriverManager.getConnection(connectURL);
            System.out.println("Connect to database successful!!");
        }
       catch(ClassNotFoundException | SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
       return conn;
    }
}
