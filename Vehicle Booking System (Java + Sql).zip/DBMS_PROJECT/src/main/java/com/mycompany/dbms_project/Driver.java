package com.mycompany.dbms_project;

import java.sql.*;
import javax.swing.JOptionPane;

public class Driver {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    //ResultSet res=null;
    
    String Name,Pass,Phn,Lic;
    
    public boolean signup(String FullName,String Cnic, String PhoneNo, String LicenseNo, String Password) throws SQLException{
        boolean b = false;
        String icnic = Cnic;
        String iname = FullName;
        String iphoneNo = PhoneNo;
        String ilicenseno = LicenseNo;
        String ipass = Password;

        try(CallableStatement istmt = con_obj.prepareCall("{call InsertDriverRecord(?, ?, ?, ?, ?, ?)}")){
            
            istmt.setString(1, icnic);
            istmt.setString(2, iname);
            istmt.setString(3, iphoneNo);
            istmt.setString(4, ilicenseno);
            istmt.setString(5, iname);
            istmt.setString(6, ipass);

            istmt.execute();
            b=true;
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        return b;
    }
    
    public boolean signin(String Username, String Password){
        boolean b = false;
        String iuname = Username;
        String ipass = Password;

        try (CallableStatement stmt2 = con_obj.prepareCall("{call MatchDriverUsernamePassword(?, ?)}")) {

            stmt2.setString(1, iuname);
            stmt2.setString(2, ipass);

            ResultSet resultSet = stmt2.executeQuery();

            if (resultSet.next()) {
                System.out.println("Username and password matched.");
                b = true;
            } else {
                 JOptionPane.showMessageDialog(null, "Invalid username or password.");
                 b = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } 
        return b;
    }
    
    public boolean driver(String cnic){
        boolean b = false;
        try (CallableStatement stmt3 = con_obj.prepareCall("{call GetDriverDetailsByCNIC(?)}")) {
            
            stmt3.setString(1, cnic);

            ResultSet resultSet = stmt3.executeQuery();

            if (resultSet.next()) {
                Name = resultSet.getString("DriverName");
                Phn = resultSet.getString("PhoneNo");
                Lic = resultSet.getString("LicenseNo");
                Pass = resultSet.getString("Password");
                b = true;
            } else {
                JOptionPane.showMessageDialog(null, "No driver found with the given CNIC.");
                b = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean updateDriver(String name, String cnic, String phn, String lic, String pass){
        boolean b = false;
        String ucnic = cnic;
        String uname = name;
        String uphoneNo = phn;
        String ulicenseNo = lic;
        String upass = pass;

        try (CallableStatement stmt4 = con_obj.prepareCall("{call UpdateDriverDetails(?, ?, ?, ?, ?)}")) {

            stmt4.setString(1, ucnic);
            stmt4.setString(2, uname);
            stmt4.setString(3, uphoneNo);
            stmt4.setString(4, ulicenseNo);
            stmt4.setString(5, upass);

            int rowsAffected = stmt4.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Driver details updated successfully.");
                b = true;
            } else {
                JOptionPane.showMessageDialog(null, "No driver found with the given CNIC.");
                b = false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }
    
    public boolean registerVehicle(String cnic, String licensePlateNo, String make, String model, int capacity, String vehicleType) {
        boolean success = false;

        try (CallableStatement stmt4 = con_obj.prepareCall("{call RegisterVehicle(?, ?, ?, ?, ?, ?)}")) {
            stmt4.setString(1, cnic);
            stmt4.setString(2, licensePlateNo);
            stmt4.setString(3, make);
            stmt4.setString(4, model);
            stmt4.setInt(5, capacity);
            stmt4.setString(6, vehicleType);
            
            boolean hasResults = stmt4.execute();
            if (hasResults) {
                ResultSet rs = stmt4.getResultSet();
                if (rs.next()) {
                    String result = rs.getString("Result");
                    JOptionPane.showMessageDialog(null, result);
                }
            }
            success = true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
            success = false;
        }
        return success;
    }
}
