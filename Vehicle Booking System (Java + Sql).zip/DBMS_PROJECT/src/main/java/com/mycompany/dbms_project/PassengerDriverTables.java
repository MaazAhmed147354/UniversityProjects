package com.mycompany.dbms_project;

import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class PassengerDriverTables {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj=con.EstablishConnection();
    Statement stmt=null;//used for insert, update & delete
    PreparedStatement pstmt=null;//used for select
    ResultSet res=null;
    
    public void showPassengerTable(JTable table, String cnic) {
        try {
            // Create a statement
            stmt = con_obj.createStatement();

            // SQL statement to call the SQL Server function
            String sql = "SELECT * FROM GetCustomerBookingHistory(?)";
            pstmt = con_obj.prepareStatement(sql);
            pstmt.setString(1, cnic); // Set the parameter value

            // Execute the query
            res = pstmt.executeQuery();

            // Create a DefaultTableModel
            DefaultTableModel tableModel = new DefaultTableModel();

            // Get the column names from the result set metadata
            for (int i = 1; i <= res.getMetaData().getColumnCount(); i++) {
                tableModel.addColumn(res.getMetaData().getColumnName(i));
            }

            // Populate the table model with data from the result set
            while (res.next()) {
                Object[] rowData = new Object[res.getMetaData().getColumnCount()];
                for (int i = 1; i <= res.getMetaData().getColumnCount(); i++) {
                    rowData[i - 1] = res.getObject(i);
                }
                tableModel.addRow(rowData);
            }

            // Set the table model
            table.setModel(tableModel);

            // Close the result set, statement, and connection
            res.close();
            stmt.close();
            con_obj.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void showDriverTable(JTable table, String cnic) {
        try {
            // Create a statement
            stmt = con_obj.createStatement();

            // SQL statement to call the SQL Server function
            String sql = "SELECT * FROM GetDriverBookingHistory(?)";
            pstmt = con_obj.prepareStatement(sql);
            pstmt.setString(1, cnic); // Set the parameter value

            // Execute the query
            res = pstmt.executeQuery();

            // Create a DefaultTableModel
            DefaultTableModel tableModel = new DefaultTableModel();

            // Get the column names from the result set metadata
            for (int i = 1; i <= res.getMetaData().getColumnCount(); i++) {
                tableModel.addColumn(res.getMetaData().getColumnName(i));
            }

            // Populate the table model with data from the result set
            while (res.next()) {
                Object[] rowData = new Object[res.getMetaData().getColumnCount()];
                for (int i = 1; i <= res.getMetaData().getColumnCount(); i++) {
                    rowData[i - 1] = res.getObject(i);
                }
                tableModel.addRow(rowData);
            }

            // Set the table model
            table.setModel(tableModel);

            // Close the result set, statement, and connection
            res.close();
            stmt.close();
            con_obj.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
