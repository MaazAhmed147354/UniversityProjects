public class Form_VM_System extends javax.swing.JFrame {
    ConnectionToDB con_obj=new ConnectionToDB();
    public Form_VM_System() {
        initComponents();
        con_obj.EstablishConnection();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblHeading = new javax.swing.JLabel();
        lblAdmin = new javax.swing.JLabel();
        btnAdmin = new javax.swing.JButton();
        lblCitizen = new javax.swing.JLabel();
        btnCitizen = new javax.swing.JButton();
        lblCandidate = new javax.swing.JLabel();
        btnCandidate = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblHeading.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        lblHeading.setText("VOTING MANAGEMENT SYSTEM");

        lblAdmin.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblAdmin.setForeground(java.awt.Color.red);
        lblAdmin.setText("    ADMIN");
        lblAdmin.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        btnAdmin.setBackground(java.awt.Color.red);
        btnAdmin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnAdmin.setText("Click Here!");
        btnAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminActionPerformed(evt);
            }
        });

        lblCitizen.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblCitizen.setForeground(java.awt.Color.green);
        lblCitizen.setText("   CITIZEN");
        lblCitizen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        btnCitizen.setBackground(java.awt.Color.green);
        btnCitizen.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnCitizen.setText("Click Here!");
        btnCitizen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCitizenActionPerformed(evt);
            }
        });

        lblCandidate.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lblCandidate.setForeground(java.awt.Color.blue);
        lblCandidate.setText("CANDIDATE");

        btnCandidate.setBackground(java.awt.Color.blue);
        btnCandidate.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnCandidate.setText("Click Here!");
        btnCandidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCandidateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCandidate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblCandidate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnAdmin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(103, 103, 103)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCitizen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblCitizen, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(97, 97, 97))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblHeading, javax.swing.GroupLayout.DEFAULT_SIZE, 779, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblHeading)
                .addGap(112, 112, 112)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblCitizen)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCitizen))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(lblAdmin)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnAdmin))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(lblCandidate)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnCandidate))))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCandidateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCandidateActionPerformed
        Form_Candidate_Login can=new Form_Candidate_Login();
        can.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnCandidateActionPerformed

    private void btnAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdminActionPerformed
        Form_Admin_Login adm=new Form_Admin_Login();
        adm.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnAdminActionPerformed

    private void btnCitizenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCitizenActionPerformed
        Form_Citizen_Login cit=new Form_Citizen_Login();
        cit.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnCitizenActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_VM_System.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_VM_System.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_VM_System.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_VM_System.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_VM_System().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdmin;
    private javax.swing.JButton btnCandidate;
    private javax.swing.JButton btnCitizen;
    private javax.swing.JLabel lblAdmin;
    private javax.swing.JLabel lblCandidate;
    private javax.swing.JLabel lblCitizen;
    private javax.swing.JLabel lblHeading;
    // End of variables declaration//GEN-END:variables
}
